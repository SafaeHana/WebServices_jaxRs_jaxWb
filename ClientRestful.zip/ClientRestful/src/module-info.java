/**
 * 
 */
/**
 * @author abdou
 *
 */
module ClientRestful {
}